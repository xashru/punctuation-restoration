test_path = '../../UTT data\processed_data\sw07utt\sw02006.utt'


def get_start_time(text):
	return float(text.split(' ')[0][10:16])

segments_file = open('text', "r", encoding="utf-8")
lines = segments_file.readlines()
lines = list(filter(lambda x: x[:7] == 'sw02073', lines))
lines = list(map(lambda x: x.strip(), lines))
lines.sort(key=get_start_time)
lines = list(map(lambda x: x.split('-', 1)[1], lines))
# lines = lines.split(' ')
# lines = list(filter(lambda x: len(x) != 1, lines))
print('\n'.join(lines))
